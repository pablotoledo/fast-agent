from mcp_agent.cli.main import app

# This must be here for the console entry points defined in pyproject.toml
# DO NOT REMOVE!

if __name__ == "__main__":
    app()
