"""
Prompting examples package for MCP Agent.
"""
