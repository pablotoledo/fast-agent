"""
Helper modules for working with MCP content.
"""